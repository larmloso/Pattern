public interface AreaVisitor {

    int visit(Rectangle rectangle);
    int visit(Triangle triangle);
    
}