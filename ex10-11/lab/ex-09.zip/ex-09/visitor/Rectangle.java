public class Rectangle implements Area {

    private int width;
    private int length;

    public Rectangle(int width, int length) {
        this.width = width;
        this.length = length;
    }

    public int getWidth() {
        return width;
    }

    public int getLength() {
        return length;
    }

    @Override
    public int calculate(AreaVisitor visitor) {
        return visitor.visit(this);
    }
}