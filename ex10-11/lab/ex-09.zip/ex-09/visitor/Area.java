public interface Area {

    public int calculate(AreaVisitor visitor);
  
}