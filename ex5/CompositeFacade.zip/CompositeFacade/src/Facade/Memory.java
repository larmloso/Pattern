package Facade;

public class Memory {    
    public void load(long position, byte[] data) {
        System.out.println("Memory is loading...");
    }
}
