package Facade;

public class CPU {

    public void freeze() {
        System.out.println("CPU is freezing...");
    }

    public void jump(long position) {
        System.out.println("CPU is jumping ..." + position);
    }

    public void execute() {
        System.out.println("CPU is executing...");
    }
}
