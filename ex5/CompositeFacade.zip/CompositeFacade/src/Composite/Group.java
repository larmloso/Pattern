package Composite;

public interface Group {
    public void assemble();
}
