package CommandByDerek;

public class DemoCommand {

    public static void main(String[] args) {
        
        //--------------------------------------------------------------------------
        // INVOKER: DeviceButton => COMMAND: CommandTurnTVOn.execute() => Television.on()
        //--------------------------------------------------------------------------
        
        // new Television()
        ElectronicDevice newDevice = TVRemote.getDevice();
        
        // pass Television to COMMAND : CommandTurnTVOn
        CommandTurnTVOn turnTVOnCommand = new CommandTurnTVOn(newDevice);
        
        // แทนที่จะทำ cmdTurnTVOn.execute() ก็ให้ INVOKER สั่ง cmdTurnTVOn
        // pass cmdTurnTVOn to INVOKER : DeviceButton
        DeviceButton onPressed = new DeviceButton(turnTVOnCommand);
        onPressed.press();

        //----------------------------------------------------------
        // test Volume up
        //
        CommandTurnTVUp volUpCommand = new CommandTurnTVUp(newDevice);
        onPressed = new DeviceButton(volUpCommand);
        onPressed.press();
        onPressed.press();
        onPressed.press();
    }
    
}
