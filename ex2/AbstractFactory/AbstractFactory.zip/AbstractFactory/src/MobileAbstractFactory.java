

public interface MobileAbstractFactory {
    public Mobile createMobile();
}
