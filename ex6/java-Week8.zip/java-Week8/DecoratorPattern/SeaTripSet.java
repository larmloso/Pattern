public class SeaTripSet implements SeaTrip {

    @Override
    public void assemble() {
        System.out.print("Swimsuit");
    }
}