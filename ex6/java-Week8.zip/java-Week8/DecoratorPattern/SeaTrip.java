public interface SeaTrip {
    public void assemble ();
}