public class RubberRing extends Equipment {

    public RubberRing(SeaTrip s) {
        super(s);
    }

    @Override
    public void assemble() {
        super.assemble();
    System.out.print(" Rubber ring ");
    }
}