
public class NiceEmployees implements Employees {

    @Override
    public void conductReport(String listname) {
        System.out.println(listname + " has good behavior. ");
    }
}
