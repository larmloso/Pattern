public interface Employees {
    
    public void conductReport(String listname) throws Exception;
}