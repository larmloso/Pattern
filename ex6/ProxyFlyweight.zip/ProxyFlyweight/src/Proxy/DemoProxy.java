package Proxy;

public class DemoProxy {

    public static void main(String[] args) {
        CommandExecutor executor = new CommandExecutorProxy("admin", "12");
        try {
            executor.runCommand("someCommand");
        } catch (Exception e) {
            System.out.println("Exception Message:: " + e.getMessage());
        }
    }
}
